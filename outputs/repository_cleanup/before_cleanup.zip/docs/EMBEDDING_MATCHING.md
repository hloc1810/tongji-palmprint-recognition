# ResNet18 512-D Embedding Matching (M4-E2)

## Scope and distinction

This is an **evaluation-only** alternative to M4's frozen 600-class logit ranking (M4-E1).
It uses the **same** pre-trained+fine-tuned checkpoint. It does **not** train a new
embedding loss, projection head, or classifier. It therefore tests whether the current
512-D penultimate features support metric matching; it does not guarantee improved Rank-1.

Official ROI in the repository is **128×128** grayscale, upsampled to 224×224 and
normalized using the same eval transforms as M4-E1. Upsampling does not create new detail.

```
ROI(128×128) -> grayscale repeated to RGB -> resize(224×224)
 -> ResNet18 (remove final FC only) -> avgpool -> flatten(512)
 -> L2 normalize -> cosine similarity -> per-class aggregation -> 600 Palm ID ranks
```

## Cross-session setup

- **Gallery:** 6,000 session1 images, 10 per Palm ID (1..600), 512-D L2-normalized.
- **Query:** 6,000 session2 images, held out from feature-extractor training.
- `nearest`: For each Palm ID, maximum cosine similarity across its gallery templates.
- `centroid`: Average L2-normalized embeddings per Palm ID, then L2-normalize the
  class mean, and take cosine against each class centroid.
- Internal metrics use **negative cosine similarity** because the project's ranking
  API expects **lower is better**. Values are similarity scores, not probabilities.
- Validation diagnostics use `best_dev.pth` and only Session1 folds 1–4 (gallery)
  and fold0 (queries). The same fold0 was used for original checkpoint selection,
  so these results are not an independent estimate of generalization.
- `embedding-evaluate` does NOT change the original `resnet18_seed*.pth`, original
  `evaluate` outputs, manifests, or other three classical models.

## Commands

Install project with `pip install -e '.[cnn]'` from project root, then run:

```bash
# Optional diagnostic before touching the test (not independent CV):
palmprint-cnn --workspace . embedding-validate --seed 17 --strategy both --device cpu

# Build the Gallery without reading Session2 (can be used in demo immediately):
palmprint-cnn --workspace . embedding-gallery --seed 17 --device cpu

# Final evaluation of both fixed score aggregation methods:
palmprint-cnn --workspace . embedding-evaluate --seed 17 --strategy both --batch-size 32 --device cpu
palmprint-cnn --workspace . embedding-evaluate --seed 29 --strategy both --batch-size 32 --device cpu
palmprint-cnn --workspace . embedding-evaluate --seed 43 --strategy both --batch-size 32 --device cpu

# Predict one official 128x128 ROI (after gallery built):
palmprint-cnn --workspace . embedding-predict --seed 17 --strategy nearest \
  --image path/to/official_roi.bmp --device cpu
```

`--device auto` selects CUDA when available, otherwise CPU. With torch-directml installed
in a compatible environment, `--device directml:0` can be used. For `--workspace`,
use the project directory containing `data/metadata` and `artifacts`.

Expected artifacts:

- `artifacts/resnet18_seed17_gallery512.npz` containing session1 features/IDs and hashes.
- `outputs/runs/resnet18_seed17_embedding_nearest/metrics.json` and evidence CSV/NPZ.
- `outputs/runs/resnet18_seed17_embedding_centroid/metrics.json` and evidence CSV/NPZ.
- Original M4 classification files are left untouched.

The gallery cache is tied to the frozen checkpoint SHA256, manifest SHA256, image size,
ordered UID list and Palm IDs; a mismatch causes a hard error rather than silent reuse.
Stored embedding vectors are biometric-derived data; do not publish or redistribute
these generated galleries or checkpoints without data-use permission.

## Scientific interpretation

The previous project reported 98.4–98.9% fold0 validation Rank-1 and 63.4–65.5%
session2 Rank-1 for three ResNet18 seeds, indicating a large cross-session gap.
Cosine matching may improve rankings, but the feature backbone and training still
have the same cross-session limitations. Neither strategy should be selected *because*
of which scores higher on session2. The project itself documents historical pilot use
of parts of session2; report new evaluations as exploratory/post-hoc comparisons.

No test metrics for the new embedding method are included here; the supplied archive
has no real image data or frozen `.pth` checkpoint. Run the commands locally with
those files available to compute the real Tongji results.
