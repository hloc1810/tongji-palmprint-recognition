# Phạm vi triển khai và điều kiện nghiệm thu

Giai đoạn 1 đã có [hồ sơ Research correctness](RESEARCH_CORRECTNESS.md): audit cấu trúc/mã hiện có, chuẩn hóa mô tả toán học và metadata, siết kiểm chứng report/cache, 51 test đạt trên từng Python 3.11/3.12 và strict audit 12.000 ROI cục bộ. Chưa có benchmark accuracy Tongji được chạy trong giai đoạn này.

## Thành phần mã nguồn

| Thành phần | Vị trí triển khai | Phương thức kiểm tra |
|---|---|---|
| Dataset Tongji, nhãn, thống kê chất lượng, SHA-256 | `src/palmprint/data/dataset.py` | `tests/test_dataset.py`, `palmprint prepare` |
| Chia 5 fold trên session1 | `src/palmprint/data/dataset.py` | `tests/test_dataset.py`, `tests/test_lifecycle.py` |
| Gabor/CompCode histogram và biểu diễn đối chứng | `src/palmprint/features/compcode.py`, `src/palmprint/features/extraction.py` | `tests/test_features.py` |
| 1-NN, Linear SVM, CRC_RLS | `src/palmprint/models/classical.py` | `tests/test_models.py` |
| Cross-validation, chọn tham số, khóa mô hình, đánh giá test | `src/palmprint/training/selection.py`, `src/palmprint/training/classical.py` | `tests/test_lifecycle.py`, `tests/test_audit_contract.py` |
| CNN ResNet18, fine-tuning hai giai đoạn, checkpoints | `src/palmprint/training/cnn.py` | `tests/test_training.py`, `tests/test_cnn.py` |
| Rank-1/5, Macro-F1, CMC, confusion, bootstrap CI | `src/palmprint/evaluation/metrics.py` | `tests/test_metrics.py` |
| EDA, phân tích sai số, benchmark và bảng kết quả | `src/palmprint/evaluation/analysis.py`, `src/palmprint/reporting/summary.py` | `tests/test_analysis.py`, smoke test |
| Demo dự đoán từ artifact (một mô hình/lượt, Top-5) | `app/main.py` | Kiểm tra thủ công với artifact hợp lệ; chưa có kiểm thử giao diện tự động |

Định dạng tệp và đường dẫn đầu ra được mô tả trong [`MODEL_VALIDATION.md`](MODEL_VALIDATION.md). Hướng dẫn huấn luyện nằm trong [`TRAINING_GUIDE.md`](TRAINING_GUIDE.md).

## Điều kiện cần đáp ứng trước khi công bố kết quả trên Tongji

- [ ] Có minh chứng giảng viên phê duyệt nguồn dữ liệu và quyền sử dụng ảnh.
- [ ] Có đủ bộ Tongji Official ROI, qua bước kiểm kê 600 Palm ID và 12.000 ảnh.
- [ ] Đối chiếu bản triển khai Python CompCode với mã tham chiếu MATLAB của tác giả ở mức intermediate maps, histogram và đầu ra nhận dạng; ghi lại sai khác nếu có.
- [ ] Chạy cross-validation, fit và đánh giá M1–M3 trên Tongji thật theo protocol cố định.
- [ ] Chạy ResNet18 với trọng số pretrained và thiết bị được ghi nhận; lưu thống kê theo từng seed.
- [ ] Có bảng Rank-1/Rank-5/Macro-F1, CMC, confusion, paired CI và latency từ mẫu thực tế.
- [ ] Có phân tích minh họa các trường hợp nhận dạng sai, bảng phân công nhóm, báo cáo 20–30 trang và slide.
- [ ] Công khai giới hạn độc lập của test do pilot HOG trước đây từng sử dụng một phần session2 của 120 Palm ID.

## Giới hạn phương pháp

- Chế độ synthetic/`strict=False` phục vụ kiểm thử, không phải benchmark sinh trắc học Tongji.
- Điểm CRC_RLS và CompCode dựa trên triển khai Python; chưa có bằng chứng tương đương số học với MATLAB của tác giả.
- Matching time khi chia đều theo batch khác với độ trễ end-to-end của một ảnh. Dùng lệnh `palmprint benchmark` để đo tổng thời gian.
- Trọng số ResNet18 pretrained và ảnh sinh trắc học không được đính kèm vào mã nguồn.
- Giao thức khóa ba mô hình cổ điển chưa tự động khóa toàn bộ cấu hình/seed của CNN; cấu hình CNN cần được đăng ký trước lần đánh giá session2 đầu tiên. `palmprint report` liệt kê mỗi CNN seed theo run riêng, chưa tự sinh bảng **mean±std của ba seed**.
- `reports/report/REPORT_TEMPLATE.md` và `reports/slides/SLIDE_OUTLINE.md` là **đề cương**, không phải báo cáo 20–30 trang hoặc slide đã hoàn thành. Dashboard CMC/confusion và nút so sánh bốn mô hình chưa có trong Streamlit.

## Kiểm thử cục bộ

```bash
python -m pip install -e '.[test]'
python -m pytest -q
python scripts/run_smoke.py
```

Tài liệu kiểm thử: [`QUALITY_ASSURANCE.md`](QUALITY_ASSURANCE.md).
