# M4-E2: ResNet18 Embedding Matching — Tongji Contactless Palmprint

## Mục tiêu

Bổ sung phương pháp nhận dạng 1:N dựa trên embedding cho ResNet18 đã huấn luyện. Phương pháp
**không thay đổi trọng số ResNet18**, không huấn luyện metric loss mới và không ghi đè
kết quả M4-E1 (600-class classification) hiện có.

Giao thức:

- Input: ảnh Official ROI 128×128 grayscale; dùng lại preprocessing evaluation của project.
- Backbone: ResNet18, thay tầng `fc` bằng `Identity` **sau khi** nạp state_dict của checkpoint.
- Output: vector 512 chiều trước tầng `fc`; L2-normalize vector.
- Gallery: 6.000 ảnh Session 1 (600 lớp, 10 ảnh/lớp).
- Query: 6.000 ảnh Session 2 (600 lớp, 10 ảnh/lớp).
- Ranking: cosine similarity với hai chiến lược nearest-template hoặc centroid.
- Metrics: Rank-1/Rank-5/Macro-F1, CMC và confusion matrix 600×600.

Định nghĩa:

\[
 z(x)=\frac{f_\theta(x)}{\|f_\theta(x)\|_2},\qquad
 s(x,g)=z(x)^\top z(g).
\]

**Nearest template:**

\[
 S_k(x)=\max_{g\in\mathcal G_k}s(x,g),\qquad
 \hat{k}=\arg\max_k S_k(x).
\]

**Centroid:**

\[
 c_k=\operatorname{L2Norm}\left(\frac{1}{|\mathcal G_k|}\sum_{g\in\mathcal G_k}z(g)\right),
 \qquad S_k(x)=z(x)^\top c_k.
\]

Hàm `ranking` của project quy định **score càng nhỏ càng tốt**, vì vậy code chuyển
similarity sang `-cosine_similarity` trước khi xếp hạng. Điều này không làm thay đổi
thứ tự kết quả.

## Chạy với checkpoint hiện có

Cần có 3 nhóm file tại project đang chạy:

1. `data/metadata/manifest.csv` và `data/metadata/local_dataset.json`.
2. Ảnh ROI thật ở `data_root` được trỏ tới trong `local_dataset.json`.
3. `artifacts/resnet18_seed17.pth` và `artifacts/resnet18_seed17_freeze.json`
   (lặp tương tự cho seed 29/43).

Chạy trong thư mục project sau khi `pip install -e '.[cnn]'`:

```bash
# Xây dựng gallery từ Session 1; không đọc ảnh Session 2:
palmprint-cnn --workspace . embedding-gallery --seed 17 --device cpu

# Đo trực tiếp cả nearest-template và centroid trên Session 2:
palmprint-cnn --workspace . embedding-evaluate --seed 17 --strategy both --device cpu

# Nhận dạng một ảnh Official ROI 128x128:
palmprint-cnn --workspace . embedding-predict --seed 17 --strategy nearest --image /path/to/roi.bmp
```

Để báo cáo nhiều seed, chạy `embedding-evaluate` lần lượt với 17, 29, 43 và thống kê
mean ± sample SD của Rank-1/Rank-5/Macro-F1. Không lựa chọn seed theo Session 2.

**Các file xuất:** `artifacts/resnet18_seed17_gallery512.npz`,
`outputs/runs/resnet18_seed17_embedding_nearest/` và
`outputs/runs/resnet18_seed17_embedding_centroid/`.

## Giới hạn đánh giá

- File ZIP đầu vào **không đính kèm ảnh ROI thực và checkpoint `.pth`**, nên ở đây
  chỉ kiểm tra pipeline với dữ liệu giả lập; không có kết quả Rank-1 thật cho E2.
- Trong project gốc, kết quả validation nội phiên ở ba seed đạt gần 98,4–98,9%,
  còn test Session 2 khoảng 63,4–65,5%; đây là tín hiệu rõ về khoảng cách hai phiên.
- Thay phép phân loại logits bằng cosine matching **không đồng nghĩa** mô hình đã học
  embedding chuyên dụng bằng contrastive/triplet/ArcFace loss.
- Tài liệu gốc của project đã ghi Session 2 từng được sử dụng trong pilot;
  nếu tiếp tục đánh giá E2, hãy ghi là **phân tích bổ sung sau thử nghiệm**, không
  trình bày như nghiên cứu dùng một test set hoàn toàn chưa từng xem.
- Cần kiểm soát an toàn dữ liệu sinh trắc; không đưa gallery embedding lên nguồn mở.
