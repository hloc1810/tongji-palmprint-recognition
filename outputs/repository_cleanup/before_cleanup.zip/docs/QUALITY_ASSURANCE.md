# Kiểm thử phần mềm và giới hạn xác minh

Đợt Research correctness ngày 01/11/2026: **51 passed trên Python 3.11.15 và 51 passed trên Python 3.12.13**, không skip khi đã cài PyTorch/torchvision CPU; smoke và compile đều đạt ở cả hai môi trường. Kiểm kê strict cục bộ đủ 12.000 ROI/600 Palm ID và kiểm tra CompCode trên 5 ROI thật đã đạt. Chi tiết, lệnh tái lập và đường dẫn log trong [RESEARCH_CORRECTNESS.md](RESEARCH_CORRECTNESS.md). Đây là xác minh phần mềm và đầu vào, chưa phải benchmark nhận dạng Tongji. CI source vẫn cài `[test]`, nên các test CNN sẽ skip nếu runner không được cài thêm `[cnn]`.

## Phạm vi kiểm thử

- `python -m pytest -q`: kiểm tra — parser nhãn và fold, CompCode 6 hướng/histogram, CRC_RLS vs nghiệm ridge trực tiếp, Top-k, bootstrap, vòng đời freeze/evaluate, EDA/error/benchmark/robustness, CNN architecture, CNN hai giai đoạn với gradient accumulation/AMP CPU fallback, checkpoint `weights_only=True`, CLI nạp YAML và dataset picklable trên Windows.
- `python scripts/run_smoke.py`: chạy trọn vòng prepare, CV, fit final, evaluate, report cho k-NN/SVM/CRC_RLS trên **fixture tổng hợp**.
- Ablation riêng session1: global CompCode + CRC, HOG + SVM; được kiểm tra trên fixture tổng hợp.
- ResNet18 CPU (`weights=none`, ảnh 32x32, 3 lớp, 1 epoch head + 1 epoch layer4): chạy train, validation, final refit, save/load weights-only, evaluate và predict trên fixture tổng hợp; không thử pretrained ImageNet hoặc CUDA AMP trong môi trường CPU. **Không kiểm chứng pretrained ImageNet hoặc kết quả Tongji**.
- `python -m compileall src app scripts`: thành công.
- `pip install -e . --no-deps --no-build-isolation`: thành công; console script `palmprint --help` hoạt động.

## Kiểm thử pipeline cổ điển

- Kiểm tra fail-closed: không thể gọi `evaluate` trước khi khóa chung `knn`/`svm`/`crc`; không thể sửa CV/train/manifest sau lock.
- Kiểm tra dữ liệu: CV và final train không được đọc ROI session2; hash ROI từng ảnh được xác thực kể cả khi load feature từ cache; từ chối ảnh Original Images sai kích thước.
- Kiểm tra khoa học: OOF predictions có đúng một dự đoán/mẫu session1; 600 score/lớp (trên fixture: đúng số lớp) được lưu theo class order; rank/per-class/CMC/confusion/errors được tái tính và so khớp raw class scores.
- Kiểm tra giả mạo/nhầm file: chủ động thay predictions.csv, model config và một ảnh raw làm bước tiếp theo hoặc report thất bại.
- Bộ kiểm thử tự động và smoke test của ba classifier chỉ xác nhận chức năng trên dữ liệu tổng hợp, không thay thế kết quả Rank-1 trên Tongji.

## Phạm vi giao diện và tài liệu

- Streamlit hiện cho chọn một model/lượt; chưa có nút so sánh bốn model trên cùng ảnh, dashboard CMC/confusion hoặc panel kiểm tra chất lượng ROI.
- Báo cáo và slide trong `reports/` mới là đề cương. `palmprint report` xuất bảng và biểu đồ; việc viết báo cáo học thuật, đối chiếu nguồn và chọn hình minh họa vẫn cần thực hiện dựa trên kết quả thật.
- Thống kê mean±std qua ba CNN seed chưa được kết xuất tự động; có thể tính từ các `metrics.json` theo từng seed sau khi các cấu hình được đăng ký và khóa trước test.

## Chưa xác nhận

- Gói source không phân phối ảnh Tongji. Workspace cục bộ đã qua strict audit 12.000 ROI, nhưng chưa chạy full 600 classes/5-fold và đo rank thực tế.
- Không có đối chiếu trung gian với MATLAB `CR_CompCode.rar` nguồn tác giả, nên **không khẳng định tái hiện bit-exact**.
- CNN `imagenet1k_v1` thực nghiệm nhiều seed chưa chạy trên Tongji.
- Độ trễ thực tế với full gallery 6.000 samples và phần cứng của nhóm chưa đo.
- Mức độ đáp ứng tiêu chí điểm được giảng viên đánh giá từ báo cáo, mã nguồn và kết quả thực nghiệm.

## Chỉ số trong synthetic fixture

Fixture sử dụng ảnh được dựng bằng hàm sóng và nhiễu khác nhau cho mỗi lớp. Độ chính xác trên fixture (có thể đạt 100%) không có giá trị suy ra hiệu năng sinh trắc. Gói ZIP không chứa bất kỳ dữ liệu ảnh sinh trắc học hay con số giả mạo từ Tongji.
