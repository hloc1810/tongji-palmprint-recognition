# Danh mục thí nghiệm

`registry.yaml` mô tả các nhóm thí nghiệm E0–E6; lưới tham số nằm ở `configs/models.yaml` và `configs/compcode.yaml`. Các kết quả thăm dò trước đây được lưu tách khỏi kết quả kiểm thử cuối. Bảng kết quả phải kèm cấu hình, commit và hash artifact.
