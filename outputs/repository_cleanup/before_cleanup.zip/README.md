# Tongji Palmprint Recognition

**Đồ án cuối kỳ — Nhận dạng mẫu (Nhóm 01)**  
**Bài toán:** Nhận dạng lòng bàn tay không tiếp xúc (closed-set 1:N, 600 Palm ID) trên Tongji Contactless Palmprint Dataset.  
**Giao thức:** Huấn luyện/gallery từ session1; đánh giá cross-session trên session2.

> **Phạm vi kiểm chứng:** Repository cung cấp mã nguồn huấn luyện, kiểm thử, đánh giá, demo và tài liệu tái lập. Dữ liệu ảnh Tongji không nằm trong repository; kết quả từ smoke test tổng hợp không đại diện cho hiệu năng nhận dạng trên Tongji.

## Mô hình

| ID | Thuật toán | Đặc trưng/đầu vào | Mục tiêu |
|---|---|---|---|
| M1 | 1-NN nearest-template | CompCode histogram theo block | Baseline giáo trình |
| M2 | Linear SVM (OvR) | Cùng đặc trưng CompCode | So sánh classifier có kiểm soát |
| M3 | CRC_RLS (collaborative ridge) | Cùng đặc trưng CompCode | Phương pháp nhận dạng dựa trên collaborative representation |
| M4 | ResNet18 CNN | Official ROI grayscale lặp thành 3 kênh | Nhánh học sâu bổ sung |

**Tính tương đương số học với mã MATLAB CR_CompCode chính thức chưa được kiểm chứng.** CompCode trong gói là bản *paper-inspired*, chờ đối chiếu intermediate tensors với mã gốc. Các kết quả nhóm phải ghi đúng tên như vậy.

## Yêu cầu hệ thống

- Python **3.11 hoặc 3.12** được khuyến nghị; CPU đủ để chạy M1–M3, nhưng thời gian CV trên đủ 600 Palm ID phụ thuộc máy. CNN nên chạy trên GPU.
- Không tải dataset, pretrained weights hoặc model weights tự động khi cài package.
- Dữ liệu ảnh sinh trắc học không được đưa lên repo công khai; xem [`docs/DATA_PRIVACY.md`](docs/DATA_PRIVACY.md).

## Cài đặt

**Windows PowerShell:**

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -e ".[test,demo]"
# CNN: chỉ khi cần chạy ResNet18 (cài PyTorch phù hợp thiết bị của bạn)
pip install -e ".[cnn]"
pytest -q
```

**Linux/macOS:**

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e '.[test,demo,cnn]'
pytest -q
```

## Bố trí dữ liệu

Tải **Official ROI Images** qua [website tác giả Tongji](https://cslinzhang.github.io/ContactlessPalm/) theo điều khoản sử dụng. Giải nén thành:

```text
data/raw/
├── session1/
│   ├── 00001.bmp  (đuôi ảnh thực tế có thể khác)
│   └── ...
└── session2/
    ├── 00001.bmp
    └── ...
```

Trong mỗi session `00001..00010` thuộc Palm ID 1, ..., `05991..06000` thuộc Palm ID 600. **Original Images KHÔNG phải ảnh ROI**. Không trộn hai dạng dữ liệu.

## Chạy toàn bộ các mô hình cổ điển

Tất cả lệnh chạy tại **gốc repository**:

```bash
# 1. Audit + folds. Strict mode yêu cầu đúng 600 ID x 10 ảnh/session.
palmprint prepare --data data/raw
palmprint eda

# 2. Precompute feature không học từ dữ liệu
palmprint features

# 3. CV trên session1 (5-fold) và chọn siêu tham số
palmprint cv --model knn
palmprint cv --model svm
palmprint cv --model crc

# 4. Optional ablation CHỈ trên session1
palmprint cv --model crc --representation global
palmprint cv --model svm --representation hog

# 5. Sau khi kiểm tra bảng CV, mới khóa mô hình final
palmprint train --model knn
palmprint train --model svm
palmprint train --model crc

# 6. Khóa chung cả ba mô hình và bảng CV trước khi truy cập ảnh test
palmprint lock

# 7. Đánh giá session2 một lượt trên từng frozen artifact
palmprint evaluate --model knn
palmprint evaluate --model svm
palmprint evaluate --model crc

# 8. EDA lỗi, benchmark, biểu đồ báo cáo
palmprint errors --model knn
palmprint errors --model svm
palmprint errors --model crc
palmprint benchmark --model knn
palmprint benchmark --model svm
palmprint benchmark --model crc
palmprint report

# 9. Demo (yêu cầu extras demo)
streamlit run app/main.py
```

**Khóa quy trình:** `palmprint lock` yêu cầu cả ba model được huấn luyện và tạo `artifacts/protocol_lock.json`; mọi lệnh `evaluate` cổ điển từ chối chạy khi chưa khóa. CV và train không thể thay đổi sau lock. Cache chỉ chứa session1 trước khi khóa; session2 chỉ được trích xuất khi đánh giá chính thức. File ROI được kiểm tra SHA-256 theo manifest trước khi dùng, kể cả khi đọc từ cache.

**Bất biến artifact:** nếu `artifacts/<model>_freeze.json` đã tồn tại, lệnh `train` không cho ghi đè. Nếu `outputs/runs/<model>/metrics.json` tồn tại, lệnh `evaluate` từ chối lần đo thứ hai. Muốn thực hiện nghiên cứu khác, tạo workspace khác, đặt lại giao thức một cách minh bạch. Không xóa kết quả test cũ để tìm cấu hình tốt hơn.

### CNN (ResNet18)

Cấu hình huấn luyện được nạp từ `configs/resnet18.yaml`; chi tiết kỹ thuật (2-stage fine-tuning, cosine LR, early stopping, gradient clipping/accumulation, AMP, checkpoint và chống leakage) xem [`docs/TRAINING_GUIDE.md`](docs/TRAINING_GUIDE.md). Các cờ dòng lệnh có thể ghi đè cấu hình, và được lưu lại trong `training_config.json`.

```bash
# Nên có GPU; pretrained ImageNet weights có thể cần kết nối mạng để tải lần đầu.
palmprint-cnn train --seed 17 --weights imagenet1k_v1 --head-epochs 8 --finetune-epochs 5
palmprint-cnn train --seed 29 --weights imagenet1k_v1 --head-epochs 8 --finetune-epochs 5
palmprint-cnn train --seed 43 --weights imagenet1k_v1 --head-epochs 8 --finetune-epochs 5
palmprint-cnn evaluate --seed 17
palmprint-cnn evaluate --seed 29
palmprint-cnn evaluate --seed 43
palmprint report
```

`--weights none` chỉ dùng để kiểm tra kỹ thuật/offline; **không gọi là transfer learning nếu không dùng pretrained weights**. Với mỗi seed, chọn số epoch trên validation thuộc session1 rồi *huấn luyện lại* theo lịch đã khóa trên session1 đầy đủ. Không dùng session2 chọn seed tốt nhất. Lệnh `lock` hiện khóa **ba mô hình cổ điển**, không bao gồm cấu hình CNN; cần ghi nhận sẵn các CNN seed/cấu hình trước khi đánh giá test. `palmprint report` xuất mỗi CNN seed thành một dòng, **không tự tổng hợp mean±std đa seed**.

## Đầu ra phục vụ báo cáo

Mỗi mô hình cổ điển có `outputs/cv/compcode_<model>.csv`, `compcode_<model>_oof_predictions.csv`, `compcode_<model>_selection.json`. Sau đánh giá final, có `outputs/runs/<model>/metrics.json`, `predictions.csv`, `errors.csv`, `per_class_metrics.csv`, `cmc_full.csv`, `all_class_scores.npz`, `confusion_matrix.npy`, `class_order.json`. Lệnh `palmprint report` tái tính các chỉ số từ score matrix, xuất bảng so sánh, paired bootstrap, CMC/CI plots, các lớp khó và các cặp nhầm nhiều nhất. `palmprint errors`, `palmprint benchmark`, `palmprint robustness` bổ sung file phân tích riêng. Chỉ phát hành hình/ảnh sinh trắc học theo điều kiện sử dụng Tongji.

**Phạm vi demo và báo cáo:**

- Streamlit dự đoán **một mô hình mỗi lượt**. Với truy vấn từ manifest, ứng dụng hiển thị ảnh gallery Top-5; với ảnh upload tự do, ứng dụng chỉ hiện Top-5 và điểm thô.
- Giao diện hiện chưa có nút so sánh đồng thời bốn mô hình, dashboard CMC/confusion hoặc panel chất lượng ROI; bảng/hình phân tích nằm trong `reports/` sau khi chạy `palmprint report`.
- `reports/report/REPORT_TEMPLATE.md` và `reports/slides/SLIDE_OUTLINE.md` là **đề cương**, không phải bản báo cáo hoặc slide hoàn chỉnh.

**Chú ý:** thời gian `matching_ms_per_probe_batch_amortized` là thời gian classifier xử lý theo batch chia bình quân, không phải độ trễ dự đoán một ảnh có cả I/O và feature extraction. Đo thời gian end-to-end bằng `palmprint benchmark` trên cùng CPU.

## Kiểm thử với dữ liệu tổng hợp

```bash
python scripts/run_smoke.py
```

Tự tạo mẫu ảnh tổng hợp 6 Palm ID, train/test nhỏ, kiểm thử từ đầu đến cuối cả ba mô hình cổ điển và xuất biểu đồ trong thư mục tạm. **Mọi Accuracy của bước này là số tổng hợp, không được đưa vào báo cáo thực nghiệm.**

## Tổ chức mã nguồn

Các thành phần được phân theo trách nhiệm. `cli.py` và `cli_cnn.py` là điểm vào dòng lệnh; các module bên dưới triển khai nghiệp vụ và thuật toán.

```text
src/palmprint/
├── cli.py                 # Lệnh dữ liệu, CV, đánh giá và báo cáo
├── cli_cnn.py             # Lệnh CNN
├── utils.py               # Hash, cấu hình, JSON
├── data/
│   ├── dataset.py         # Kiểm tra ảnh ROI, nhãn và manifest
│   └── preparation.py     # Chuẩn bị workspace và dữ liệu
├── features/
│   ├── compcode.py        # Bộ trích đặc trưng CompCode
│   └── extraction.py      # Trích xuất và cache theo session
├── models/
│   ├── classical.py       # k-NN, SVM, CRC_RLS
│   └── resnet.py          # ResNet18 và ROI dataset
├── training/
│   ├── selection.py       # Cross-validation và chọn tham số
│   ├── classical.py       # Huấn luyện cuối, khóa và suy luận
│   └── cnn.py             # Hai giai đoạn huấn luyện CNN
├── evaluation/
│   ├── metrics.py         # Rank-k, Macro-F1 và bootstrap
│   ├── analysis.py        # EDA, phân tích lỗi, độ trễ
│   └── cnn.py             # Đánh giá và suy luận CNN
└── reporting/
    ├── evidence.py        # Xuất và kiểm chứng điểm từng lớp
    └── summary.py         # Bảng và biểu đồ báo cáo
```

Các thư mục cấp repository gồm `configs/` (cấu hình), `app/` (demo), `scripts/` (smoke test), `notebooks/`, `experiments/`, `data/`, `artifacts/`, `outputs/`, `reports/`, `tests/` và `docs/`. Sơ đồ chi tiết các thành phần và hướng phụ thuộc ở [`docs/CODE_STRUCTURE.md`](docs/CODE_STRUCTURE.md).

## Quy ước mã nguồn và tài liệu

- Mã nguồn Python dùng `snake_case` cho module/hàm/biến, `PascalCase` cho lớp; tên lệnh CLI giữ ổn định theo phần **Chạy toàn bộ các mô hình cổ điển**.
- Mã nguồn xử lý dữ liệu, mô hình và đánh giá nằm trong `src/palmprint/`; notebook chỉ phục vụ khám phá hoặc trình bày kết quả; `scripts/` dùng để thực thi tác vụ.
- Tên file tài liệu thể hiện **nội dung**, không chứa năm, nhãn phát hành hoặc lịch sử chỉnh sửa. Đường dẫn artifact đầu ra giữ đúng theo hợp đồng trong `docs/MODEL_VALIDATION.md` để bảo đảm tính tương thích.
- Các nhận định về kết quả thực nghiệm cần dẫn tới `outputs/` và cấu hình tương ứng; dữ liệu tổng hợp chỉ phục vụ kiểm thử kỹ thuật.

## Tài liệu

- [`docs/RESEARCH_CORRECTNESS.md`](docs/RESEARCH_CORRECTNESS.md) — audit hiện trạng, đối chiếu yêu cầu P0, kế hoạch và kết quả kiểm chứng Giai đoạn 1.

- [`docs/MODEL_VALIDATION.md`](docs/MODEL_VALIDATION.md) — thuật toán k-NN/SVM/CRC_RLS và đặc tả dữ liệu đầu ra.
- [`docs/RESEARCH_PLAN.md`](docs/RESEARCH_PLAN.md) — kế hoạch nghiên cứu và phạm vi chính thức của nhóm.
- [`docs/EXPERIMENT_PROTOCOL.md`](docs/EXPERIMENT_PROTOCOL.md) — split, chọn tham số, chống leakage, ablation, thống kê.
- [`docs/ALGORITHMS.md`](docs/ALGORITHMS.md) — thiết kế CompCode, k-NN, SVM, CRC_RLS, CNN, công thức.
- [`docs/TRAINING_GUIDE.md`](docs/TRAINING_GUIDE.md) — kỹ thuật huấn luyện và validation chi tiết, lệnh chạy và tiêu chí nghiệm thu.
- [`docs/REPRODUCIBILITY.md`](docs/REPRODUCIBILITY.md) — cache, artifact, lệnh chạy, xử lý lỗi, tái lập.
- [`docs/DATA_PRIVACY.md`](docs/DATA_PRIVACY.md) — dataset, sinh trắc học, giới hạn demo.
- [`docs/PROJECT_STATUS.md`](docs/PROJECT_STATUS.md) — phạm vi triển khai và điều kiện nghiệm thu.
- [`reports/report/REPORT_TEMPLATE.md`](reports/report/REPORT_TEMPLATE.md) — đề cương báo cáo 20–30 trang.
- [`reports/slides/SLIDE_OUTLINE.md`](reports/slides/SLIDE_OUTLINE.md) — nội dung slide phản biện.

## Tài liệu tham khảo chính

- L. Zhang et al., **Towards contactless palmprint recognition: A novel device, a new benchmark, and a collaborative representation based identification approach**, *Pattern Recognition*, 69 (2017), 199–212, DOI: 10.1016/j.patcog.2017.04.016. [Dataset/code chính thức](https://cslinzhang.github.io/ContactlessPalm/).
- R. O. Duda, P. E. Hart, D. G. Stork, *Pattern Classification*, 2nd ed., Wiley: Ch. 4 (k-NN), Ch. 5 (SVM), Ch. 6 (Neural Networks), Ch. 9 (đánh giá classifiers).

**Giới hạn:** Ảnh Tongji thu trong môi trường tương đối có kiểm soát; kết quả không mặc nhiên áp dụng cho camera điện thoại, ảnh ngoài tập đăng ký hoặc xác minh danh tính thực tế.


## M4-E2 — ResNet18 512-D cosine gallery matching

An evaluation-only alternative to the original M4 600-way logits has been added.
It uses the original frozen ResNet18 checkpoint and stores a session1-only gallery.
For commands, data protocol and limitations, see [docs/EMBEDDING_MATCHING.md](docs/EMBEDDING_MATCHING.md).
